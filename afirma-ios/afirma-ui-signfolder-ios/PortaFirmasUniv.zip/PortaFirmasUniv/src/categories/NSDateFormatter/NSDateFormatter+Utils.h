//
//  NSDateFormatter+Utils.h
//  bluekiwi
//
//  Created by David Arrufat on 17/02/14.
//  Copyright (c) 2014 Tempos 21. All rights reserved.
//

@interface NSDateFormatter (Utils)

- (id) initWithCurrentLocale;

@end
