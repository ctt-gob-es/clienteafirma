//
//  SignLine.m
//  TopSongs
//
//  Created by Antonio Fiñana on 31/10/12.
//
//

#import "SignLine.h"

@implementation SignLine

@synthesize receivers,errorCode,errorMsg;

@end
