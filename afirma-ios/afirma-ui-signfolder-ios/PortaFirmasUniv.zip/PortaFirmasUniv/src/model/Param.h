//
//  Param.h
//  PortaFirmasUniv
//
//  Created by Carlos Gamuci on 25/2/15.
//  Copyright (c) 2015 Atos. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Param : NSObject
@property (strong,nonatomic) NSString *key;
@property (strong,nonatomic) NSString *value;
@end