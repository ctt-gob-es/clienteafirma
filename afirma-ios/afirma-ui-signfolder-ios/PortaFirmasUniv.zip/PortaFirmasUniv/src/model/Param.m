//
//  Param.m
//  PortaFirmasUniv
//
//  Created by Carlos Gamuci on 25/2/15.

#import "Param.h"

@implementation Param

@synthesize key,value;

@end