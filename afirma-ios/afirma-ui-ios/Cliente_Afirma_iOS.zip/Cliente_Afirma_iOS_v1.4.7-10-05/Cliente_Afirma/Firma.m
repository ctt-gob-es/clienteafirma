//
//  Firma.m
//  SignSample02
//
//  Created by Juliana Marulanada on 7/1/16.
//  Copyright © 2016 Atos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Firma.h"

@implementation Firma

@end