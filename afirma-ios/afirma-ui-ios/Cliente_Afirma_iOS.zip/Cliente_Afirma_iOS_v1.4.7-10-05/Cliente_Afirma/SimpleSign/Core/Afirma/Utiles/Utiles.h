//
//  Utiles.h
//  CadesASN1Simplificado
//
//

#ifndef CadesASN1Simplificado_Utiles_h
#define CadesASN1Simplificado_Utiles_h

static int write_out(const void *buffer, size_t size, void *app_key);

#endif
