//
//  AOTriphaseData.h
//  SignSample02
//
//  Created by User1 on 11/12/15.
//  Copyright © 2015 Atos. All rights reserved.
//

#ifndef AOTriphaseData_h
#define AOTriphaseData_h

#endif /* AOTriphaseData_h */

#import <Foundation/Foundation.h>
#import "AOCounterSignPreItems.h"

@interface AOTriphaseData : NSObject

@property (nonatomic, strong) NSString *id;

@end