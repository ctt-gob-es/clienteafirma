//
//  AOAppDelegate.h
//  SignSample02
//
//

#import <UIKit/UIKit.h>

@interface AOAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
