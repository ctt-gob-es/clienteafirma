//
//  AOEntity.m
//  SignSample02
//
//

#import "AOEntity.h"

@implementation AOEntity

@synthesize datField, formatField, algorithmField, propertiesField, idField, stServletField;

@end
