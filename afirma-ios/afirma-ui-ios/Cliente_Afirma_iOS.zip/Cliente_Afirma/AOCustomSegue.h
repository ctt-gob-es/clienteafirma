//
//  AOCustomSegue.h
//  SignSample02
//
//

#import <UIKit/UIKit.h>

@interface AOCustomSegue : UIStoryboardSegue

@end
