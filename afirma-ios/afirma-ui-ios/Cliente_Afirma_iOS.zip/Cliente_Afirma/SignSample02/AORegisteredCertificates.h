//
//  AORegisteredCertificates.h
//  SignSample02
//
//  Created by User1 on 24/11/15.
//  Copyright © 2015 Atos. All rights reserved.
//

#ifndef AORegisteredCertificates_h
#define AORegisteredCertificates_h

#import <UIKit/UIKit.h>

@interface AORegisteredCertificates : UITableViewController {
    NSMutableArray *certifictesArray;
}

@end


#endif /* AORegisteredCertificates_h */
