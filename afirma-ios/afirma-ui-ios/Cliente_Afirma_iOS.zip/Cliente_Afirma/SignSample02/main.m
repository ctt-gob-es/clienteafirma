//
//  main.m
//  SignSample02
//
//

#import <UIKit/UIKit.h>

#import "AOAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AOAppDelegate class]));
    }
}
