//
//  AOUtils.h
//  SignSample02
//
//

#import <Foundation/Foundation.h>

static NSString *const kAOUserDefaultsKeyAlias = @"alias";
static NSString *const kAOUserDefaultsKeyCurrentCertificate = @"currentCertificate";

@interface AOUtils : NSObject


@end
